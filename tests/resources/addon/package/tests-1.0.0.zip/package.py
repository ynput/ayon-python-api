name = "tests"
title = "Tests"
version = "1.0.0"

client_dir = None
# ayon_launcher_version = ">=1.0.2"

ayon_required_addons = {}
ayon_compatible_addons = {}